<template>
    <div class="visualizer-container">
      <h1>Welcome to Our Group</h1>
      <p>This is our introduction page.</p>
    </div>
  </template>
  

  