<template>
    <div>
      <h1>AI Chatbot</h1>
      <p>Chat functionality will go here.</p>
    </div>
  </template>
  