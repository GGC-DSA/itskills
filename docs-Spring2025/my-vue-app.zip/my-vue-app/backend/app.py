from flask import Flask, render_template, jsonify
from flask_cors import CORS  # ✅ Import CORS
import plotly.express as px
import pandas as pd
import json

app = Flask(__name__)
CORS(app)  # ✅ Enable CORS for all routes

# Load JSON data
combined_df = pd.read_json('combined_df.json', orient='records')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/sunburst')
def sunburst_chart():
    fig = px.sunburst(
        combined_df,
        path=['Domain', 'Category', 'Keyword'],
        values='Count',
        title='Job Market Overview: Click to Explore Technical & Soft Skills',
        color='Domain',
        color_discrete_sequence=px.colors.qualitative.Pastel,
        branchvalues='total'
    )

    fig.update_traces(
        textinfo='label',
        textfont_size=12,
        insidetextorientation='radial',
        marker=dict(line=dict(color='white', width=2)),
        maxdepth=2
    )

    fig.update_layout(
        margin=dict(t=50, l=0, r=0, b=0),
        width=800, height=800,
        title_x=0.5,
        title_font_size=24
    )

    return jsonify(json.loads(fig.to_json()))

if __name__ == '__main__':
    app.run(debug=True)
